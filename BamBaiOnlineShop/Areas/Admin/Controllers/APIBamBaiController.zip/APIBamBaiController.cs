﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BamBaiOnlineShop.Models;

namespace BamBaiOnlineShop.Areas.Admin.Controllers
{
    public class APIBamBaiController : Controller
    {
        quangtuanEntities db = new quangtuanEntities();
        // GET: Admin/APIBamBai
        public JsonResult Get_AllProduct()
        {
            db.Configuration.ProxyCreationEnabled = false;
            /*List<Product> products = db.Products.ToList();*/

            var products = (from p in db.Products
                            join ct in db.Categories
                            on p.CategoryID equals ct.CategoryID
                            select new
                            {
                                p.Category.CategoryName,
                                p.CategoryID,
                                p.ProductID,
                                p.ModelName,
                                p.ModelNumber,
                                p.ProductImage,
                                p.UnitCost,
                                p.Description,
                                p.Status
                            }).ToList();
            return Json(products, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Login(string username,string password)
        {
            password = HashMD5.MD5Hash(password);
            var check = (from ad in db.Customers
                         where ad.EmailAddress == username && ad.Password == password
                         select new { ad.FullName,ad.CustomerID,ad.EmailAddress}).ToList();
            if (check !=null)
            {
                return Json(check , JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(null,JsonRequestBehavior.AllowGet);
            }
           
        }
    }
}